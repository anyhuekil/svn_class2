package javaexp.a06_object.access.company.manager;

public class HeadMember { //����
	private String familyBrith;
	public String getFamilyBrith() {
		return familyBrith;
	}
	public void setFamilyBrith(String familyBrith) {
		this.familyBrith = familyBrith;
	}
}