package javaexp.a06_object.access.company.manager;
/* �尡 - �������� ����
 * ��������Ȯ��(searchInf()
 * */
public class StaffMember {
	private String notice;
	private ChiefMember chiefMember;
	public StaffMember() {
		chiefMember = new ChiefMember();
	}
	public ChiefMember searchInf() {
		return chiefMember;
	}
	public String getNotice() {
		return notice;
	}
	public void setNotice(String notice) {
		this.notice = notice;
	}
	public void setChiefMember(ChiefMember chiefMember) {
		this.chiefMember = chiefMember;
	}
}