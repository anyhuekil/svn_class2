package javaexp.a06_object.access.company.manager;

public class ChiefMember { // ����
	String proposalDoc; // ��Ű�����ٰ��ɵ���(default)
	private HeadMember headmember;
	public ChiefMember(){
		headmember = new HeadMember();
	}
	public HeadMember searchInfo(){ // ��������Ȯ��
		return headmember;
	}
	public String getProposalDoc() {return proposalDoc;	}

	public void setProposalDoc(String proposalDoc) {
		this.proposalDoc = proposalDoc;
	}
	public void setHeadmember(HeadMember headmember) {
		this.headmember = headmember;
	}	
}